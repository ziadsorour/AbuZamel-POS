@echo off
setlocal enabledelayedexpansion

REM AbuZamel POS - One-click launcher (Windows)
REM Starts a local web server and opens the app in the default browser.

cd /d "%~dp0"
set PORT=5173
set URL=http://localhost:%PORT%/

echo ==========================================
echo   AbuZamel POS - تشغيل النظام
echo   المسار: %cd%
echo   الرابط: %URL%
echo ==========================================
echo.

REM Try Python first
python --version >nul 2>&1
if %errorlevel%==0 (
  echo [1/3] Python موجود - تشغيل السيرفر...
  
  REM Auto-set Xprinter as Default Printer if found
  echo جاري تعيين طابعة Xprinter كطابعة افتراضية...
  powershell -NoProfile -Command "$p = Get-Printer | Where-Object {$_.Name -match 'XP-80'}; if ($p) { (New-Object -ComObject WScript.Network).SetDefaultPrinter($p[0].Name) }" >nul 2>&1

  REM Launch Chrome or Edge with Silent Printing
  reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>&1
  if %errorlevel%==0 (
      start chrome --app="%URL%" --kiosk-printing
  ) else (
      start msedge --app="%URL%" --kiosk-printing
  )
  
  echo.
  echo لاغلاق السيرفر: اقفل هذه النافذة (Ctrl+C)
  python -m http.server %PORT% >nul 2>&1
  goto :eof
)

REM Fallback to Node + npx http-server
node --version >nul 2>&1
if %errorlevel%==0 (
  echo [1/3] Python مش موجود. Node موجود - تشغيل السيرفر بـ http-server...
  echo [2/3] لو دي اول مرة: هيحمل http-server تلقائي من npx.
  
  REM Auto-set Xprinter as Default Printer if found
  echo جاري تعيين طابعة Xprinter كطابعة افتراضية...
  powershell -NoProfile -Command "$p = Get-Printer | Where-Object {$_.Name -match 'XP-80'}; if ($p) { (New-Object -ComObject WScript.Network).SetDefaultPrinter($p[0].Name) }" >nul 2>&1

  REM Launch Chrome or Edge with Silent Printing
  reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>&1
  if %errorlevel%==0 (
      start chrome --app="%URL%" --kiosk-printing
  ) else (
      start msedge --app="%URL%" --kiosk-printing
  )
  
  echo.
  echo لاغلاق السيرفر: اقفل هذه النافذة (Ctrl+C)
  npx http-server -p %PORT% -c-1 >nul 2>&1
  goto :eof
)

echo.
echo [خطأ] لا يوجد Python ولا Node على الجهاز.
echo.
echo الحل:
echo - نزّل Python من: https://www.python.org/downloads/
echo   وبعد التثبيت فعّل خيار "Add python.exe to PATH"
echo.
echo - او نزّل Node.js من: https://nodejs.org/
echo.
pause

